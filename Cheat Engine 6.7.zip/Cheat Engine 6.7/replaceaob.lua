{$lua}
if syntaxcheck then return end
cheat_name = "MyCheat"
[ENABLE]
local pattern = "48 83 EC 28 E8 ?? ?? ?? ?? 48 83 C4 28"
local replace = "?? ?? ?? ?? 90 90 90 90 90 ?? ?? ?? ??"
-- edit the name of the cheat
-- edit the pattern to search
-- edit the replacement bytes
-- use ?? to ignore the bytes
-- do not edit the code below
local scans = AOBScan(pattern)
if scans == nil then
  showMessage("Unable to find pattern:\n"..pattern)
else
  local saved = {}
  local length = (#replace + 1) / 3
  for i = 0, scans.Count - 1 do
    local backup = readBytes(scans[i], length, true)
    local bytes = {}
    for hex in string.gmatch(replace, "%S+") do
      local size = #bytes + 1
      if hex == "??" then
        bytes[size] = backup[size]
      else
        bytes[size] = tonumber(hex, 16)
      end
    end
    saved[i] = backup
    writeBytes(scans[i], bytes)
  end
  _G[cheat_name] = {
    ["scans"] = scans,
    ["saved"] = saved
  }
end
[DISABLE]
local vars = _G[cheat_name]
if vars ~= nil then
  local scans = vars.scans
  local saved = vars.saved
  for i = 0, scans.Count - 1 do
    writeBytes(scans[i], saved[i])
  end
  scans.Destroy()
  vars.scans = nil
  vars.saved = nil
  vars = nil
  _G[cheat_name] = nil
end