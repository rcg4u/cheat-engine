#ifndef PSCANFILEACCESS_H
#define PSCANFILEACCESS_H

int pscaninit();


#endif//PSCANFILEACCESS_H