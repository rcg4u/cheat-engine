#pragma once

#include <windows.h>
#include <stdio.h>
#include <tchar.h>
#include <clrdata.h>

#include <metahost.h>

#include <MSCorEE.h>
#include <cor.h>
#include <CorHdr.h>
#include <CorDebug.h>
#include <shlwapi.h>
#include <Tlhelp32.h>

#include <list>
#include <vector>
#include <map>
#include <string>

