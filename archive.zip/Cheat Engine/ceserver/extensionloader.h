/*
 * extentionloader.h
 *
 *  Created on: Aug 19, 2013
 *      Author: eric
 */

#ifndef EXTENTIONLOADER_H_
#define EXTENTIONLOADER_H_

#include "porthelp.h"

int loadCEServerExtension(HANDLE hProcess);

#endif /* EXTENTIONLOADER_H_ */
