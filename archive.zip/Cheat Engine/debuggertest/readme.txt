the debuggertest project is a simple program that can be used to tests the ce debugger for bugs.
