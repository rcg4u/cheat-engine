void InitializeCETC(void);
NTSTATUS UnloadCETC(void);