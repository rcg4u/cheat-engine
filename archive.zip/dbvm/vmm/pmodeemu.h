/*
 * pmodeemu.h
 *
 *  Created on: Jul 13, 2009
 *      Author: erich
 */

#ifndef PMODEEMU_H_
#define PMODEEMU_H_

int emulateProtectedMode(pcpuinfo currentcpuinfo, VMRegisters *vmregisters);

#endif /* PMODEEMU_H_ */
